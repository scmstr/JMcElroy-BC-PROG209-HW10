let dataArray = [];


// song object constructor
var SongObject = function (pSongName, pSongArtist, pSongAlbum, pSongAlbumReleaseDate) {
  this.SongName = pSongName;
  this.SongArtist = pSongArtist;
  this.SongAlbum = pSongAlbum;
  this.SongAlbumReleaseDate = pSongAlbumReleaseDate;
}


document.addEventListener("DOMContentLoaded", function () {
  
  // //when you click this button, sort the list by NAME, create the new list, then take us to the main list PAGE
  // var btnSortName = document.getElementById("buttonSortName");
  // btnSortName.addEventListener("click", function () {
  //   dataArray.sort(dynamicSort("SongName"));
  //   createList();
  //   document.location.href = "index.html#Page1";
  // });

  // //when you click this button, sort the list by YEAR, create the new list, then take us to the main list PAGE
  // document.getElementById("buttonSortYear").addEventListener("click", function () {
  //   dataArray.sort(dynamicSort("SongAlbumReleaseDate"));
  //   createList();
  //   document.location.href = "index.html#Page1";
  // });




  //before Page1 loads, recompile the main list - the MAIN LIST page
  $(document).on("pagebeforeshow", "#page1", function (event) {    
    createList();
    console.log("createList has been called and made this array: " + dataArray);
  });

  //before Page2 loads, clear the fields - the ADD SONG page
  $(document).on("pagebeforeshow", "#page2", function (event) {   
    createList();
  });

  //before Page3 loads, fill the existing HTML elements with the selected values from the correct array object - the song deais page
  $(document).on("pagebeforeshow", "#page3", function (event) {    
    if(document.getElementById("secretID").innerHTML == null || document.getElementById("secretID").innerHTML == "") { //------- you shouldnt be on page3 if you dont belong there
      document.location.href = "index.html#page1";
    };
    makeEmbed(document.getElementById("secretID").innerHTML);
  });

  // //before Page4 loads, clear the fields - the loading page
  // $(document).on("pagebeforeshow", "#Page4", function (event) { 
  //   document.getElementById("pSongName").value = "";
  //   document.getElementById("pSongArtist").value = "";
  //   document.getElementById("pSongAlbum").value = "";
  //   document.getElementById("pSongAlbumReleaseDate").value = "";
  //   document.location.href = "index.html#page1"
  // });




  //add song button   !!!!! NEEDS PUSH TO SERVER !!!!!
  document.getElementById("btnAddSong").addEventListener("click", function() {
  
    //create object and fill it
    var songName = document.getElementById("pSongName").value;
    var songArtist = document.getElementById("pSongArtist").value;
    var songAlbum = document.getElementById("pSongAlbum").value;
    var songAlbumReleaseDate = document.getElementById("pSongAlbumReleaseDate").value;
    var songObject = new SongObject(songName, songArtist, songAlbum, songAlbumReleaseDate);
    
    //push the object to the array
    dataArray.push(songObject);            // <------------------------------------- push new song to server array instead of client array!
                          
    //reset
    songObject = "";
    clearAddSong();
  
    //go to the list page
    document.location.href = "index.html#page1"
  });
  
});


//clears the page input boxes
function clearAddSong() {
  document.getElementById("pSongName").value = "";
  document.getElementById("pSongArtist").value = "";
  document.getElementById("pSongAlbum").value = "";
  document.getElementById("pSongAlbumReleaseDate").value = "";
};


//repopulates the client array from the server, and actually creates the unique html page/list   !!!!! NEEDS GET FROM SERVER !!!!!
function createList()
{
  FillArrayFromServer();

  var stupidity = document.getElementById("stupidity");

  console.log("stupidity.innerHTML inside createList : " + stupidity.innerHTML);
  console.log("stupidity.innerText inside createList : " + stupidity.innerText);
  console.log("stupidity.value inside createList : " + stupidity.value);

  dataArray = stupidity.innerHTML;

  console.log("dataArray inside createList : " + dataArray);


  //clear the main list page
  document.getElementById("divUserlist").innerHTML = "";

  //make a new list element
  var ul = document.createElement('ul');

  //do a foreach on the array, append entry on each object onto said list
  dataArray.forEach(function (element,index) {
    var li = document.createElement('li');
    li.innerHTML = "<a data-transition='pop' class='oneSong' onclick=viewDetails(" + index + ")> Details </a> :  " + element.SongName + " - " + element.SongArtist + "<a data-transition='pop' class='oneSong' onclick=deleteSong(" + element.SongName + ")> DELETE SONG </a>";
    ul.appendChild(li);
  });

  //add that list to the html element
  divUserlist.appendChild(ul)
};


//takes in unique song name from client list, deletes server array object of that same name
function deleteSong(songName) {




};


//pulls list from server
function FillArrayFromServer(){
  // using fetch call to communicate with node server to get all data
  fetch('/users/songList')
  .then(function (theResonsePromise) {  // wait for reply.  Note this one uses a normal function, not an => function
    return theResonsePromise.json();
  })
  theResonsePromise.json().then(function (serverData) { // now wait for the 2nd promise, which is when data has finished being returned to client

    var stupidity = document.getElementById("stupidity");

    stupidity.innerHTML = serverData;
    stupidity.innerText = serverData;
    stupidity.value = serverData;

    console.log("stupidity.innerHTML inside then : " + stupidity.innerHTML);
    console.log("stupidity.innerText inside then : " + stupidity.innerText);
    console.log("stupidity.value inside then : " + stupidity.value);
  
  })
  .catch(function (err) {
    console.log(err);
  });
};



function viewDetails(index) {
  //save songid to page
  document.getElementById("secretID").innerHTML = index;

  document.getElementById("oneTitle").innerHTML =  "";
  document.getElementById("oneYear").innerHTML =  "";
  document.getElementById("oneGenre").innerHTML =  "";
  document.getElementById("oneWoman").innerHTML =   "";
    
  document.getElementById("oneTitle").innerHTML =  dataArray[index].SongName;
  document.getElementById("oneYear").innerHTML =  dataArray[index].SongArtist;
  document.getElementById("oneGenre").innerHTML =  dataArray[index].SongAlbum;
  document.getElementById("oneWoman").innerHTML =   dataArray[index].SongAlbumReleaseDate;

  makeEmbed(index);

  document.location.href = "index.html#page3";
};


//all this does is populate the youtube video section      !!!! has weird cookie bug caused by modern securities/standards, do not plan on fixing because not scope of class, but the function and page work
function makeEmbed(index) {
  console.log("makeEmbed called with: " + index);

  var embedHere = document.getElementById("ytplayer");  

  var stringOneSongSearch = "";
  stringOneSongSearch = "https://www.youtube.com/embed?listType=search&list=" + dataArray[index].SongName + " " + dataArray[index].SongArtist + " " + dataArray[index].SongAlbum + " " + dataArray[index].SongAlbumReleaseDate + "&sp=CAM%253D?autoplay=0"; //searches by these keywords and picks the highest viewed one
  
  embedHere.setAttribute("src", ""); 
  embedHere.setAttribute("src", stringOneSongSearch); 

  console.log(embedHere.innerHTML);
};


/**
*  https://ourcodeworld.com/articles/read/764/how-to-sort-alphabetically-an-array-of-objects-by-key-in-javascript
* Function to sort alphabetically an array of objects by some specific key.
* 
* @param {String} property Key of the object to sort.
*/


function dynamicSort(property) {
  var sortOrder = 1;

  if (property[0] === "-") {
    sortOrder = -1;
    property = property.substr(1);
  }

  return function (a, b) {
    if (sortOrder == -1) {
      return b[property].localeCompare(a[property]);
    } else {
      return a[property].localeCompare(b[property]);
    }
  }
};
